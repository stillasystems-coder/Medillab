import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, bookingStatuses } from "@shared/routes";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

type CreateBookingInput = z.infer<typeof api.bookings.create.input>;
type UpdateStatusInput = z.infer<typeof api.bookings.updateStatus.input>;
type BookingStatus = typeof bookingStatuses[number];

export function useBookings(status?: BookingStatus, search?: string) {
  return useQuery({
    queryKey: [api.bookings.list.path, status, search],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (status) params.append("status", status);
      if (search) params.append("search", search);
      
      const url = `${api.bookings.list.path}?${params.toString()}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch bookings");
      return api.bookings.list.responses[200].parse(await res.json());
    },
  });
}

export function useBooking(id: number) {
  return useQuery({
    queryKey: [api.bookings.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.bookings.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) throw new Error("Booking not found");
      if (!res.ok) throw new Error("Failed to fetch booking");
      return api.bookings.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateBooking() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: CreateBookingInput) => {
      const res = await fetch(api.bookings.create.path, {
        method: api.bookings.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to create booking");
      return api.bookings.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.bookings.list.path] });
      toast({ title: "Success", description: "Booking created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create booking", variant: "destructive" });
    },
  });
}

export function useUpdateBookingStatus() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status: BookingStatus }) => {
      const url = buildUrl(api.bookings.updateStatus.path, { id });
      const res = await fetch(url, {
        method: api.bookings.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to update status");
      return api.bookings.updateStatus.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.bookings.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.bookings.get.path, variables.id] });
      toast({ title: "Status Updated", description: `Booking status changed to ${variables.status}` });
    },
  });
}

export function useUploadResult() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, file }: { id: number; file: File }) => {
      const url = buildUrl(api.bookings.uploadResult.path, { id });
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch(url, {
        method: api.bookings.uploadResult.method,
        body: formData,
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to upload result");
      return api.bookings.uploadResult.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.bookings.get.path, variables.id] });
      toast({ title: "Success", description: "Result uploaded and patient notified" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to upload result", variant: "destructive" });
    },
  });
}
