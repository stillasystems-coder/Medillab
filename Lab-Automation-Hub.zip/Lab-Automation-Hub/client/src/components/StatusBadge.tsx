import { clsx } from "clsx";
import { bookingStatuses } from "@shared/routes";

type BookingStatus = typeof bookingStatuses[number];

const statusConfig: Record<BookingStatus, { color: string; label: string }> = {
  BOOKED: { color: "bg-blue-100 text-blue-700 border-blue-200", label: "Booked" },
  ARRIVED: { color: "bg-purple-100 text-purple-700 border-purple-200", label: "Arrived" },
  SAMPLE_COLLECTED: { color: "bg-amber-100 text-amber-700 border-amber-200", label: "Sample Collected" },
  IN_PROCESS: { color: "bg-indigo-100 text-indigo-700 border-indigo-200", label: "Processing" },
  COMPLETED: { color: "bg-emerald-100 text-emerald-700 border-emerald-200", label: "Completed" },
  DELIVERED: { color: "bg-slate-100 text-slate-700 border-slate-200", label: "Delivered" },
};

export function StatusBadge({ status }: { status: string }) {
  const config = statusConfig[status as BookingStatus] || { color: "bg-gray-100 text-gray-700", label: status };
  
  return (
    <span className={clsx(
      "px-2.5 py-0.5 rounded-full text-xs font-semibold border inline-flex items-center",
      config.color
    )}>
      {config.label}
    </span>
  );
}
