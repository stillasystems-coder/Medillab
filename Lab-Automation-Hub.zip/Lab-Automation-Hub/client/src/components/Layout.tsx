import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Users, 
  FlaskConical, 
  CalendarDays, 
  LogOut, 
  Menu,
  TestTube2
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const navItems = [
  { label: "Dashboard", icon: LayoutDashboard, href: "/" },
  { label: "Bookings", icon: CalendarDays, href: "/bookings" },
  { label: "Patients", icon: Users, href: "/patients" },
  { label: "Lab Tests", icon: FlaskConical, href: "/tests" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const NavContent = () => (
    <div className="flex flex-col h-full py-6">
      <div className="px-6 mb-8 flex items-center gap-3">
        <div className="p-2 bg-primary rounded-lg">
          <TestTube2 className="h-6 w-6 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-xl font-bold font-display text-slate-900 leading-none">MediLab</h1>
          <span className="text-xs text-slate-500 font-medium">Diagnostic Automation</span>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} className={`
              flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all
              ${isActive 
                ? "bg-primary text-white shadow-lg shadow-primary/25 translate-x-1" 
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
              }
            `}>
              <item.icon className="h-5 w-5" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="px-4 mt-auto">
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 mb-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-primary font-bold text-xs">
              JD
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-semibold truncate">Jane Doe</p>
              <p className="text-xs text-slate-500 truncate">Lab Technician</p>
            </div>
          </div>
          <Button variant="outline" size="sm" className="w-full text-xs h-8" onClick={() => window.location.href = '/login'}>
            <LogOut className="h-3 w-3 mr-2" />
            Sign Out
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50/50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 bg-white border-r border-slate-200 fixed h-full z-10">
        <NavContent />
      </aside>

      {/* Mobile Sidebar */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetContent side="left" className="p-0 w-64">
          <NavContent />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 min-h-screen flex flex-col">
        <header className="h-16 bg-white/80 backdrop-blur border-b border-slate-200 sticky top-0 z-20 px-4 flex items-center justify-between lg:hidden">
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-primary rounded-md">
              <TestTube2 className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-bold font-display text-lg">MediLab</span>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setIsOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
        </header>

        <div className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {children}
        </div>
      </main>
    </div>
  );
}
