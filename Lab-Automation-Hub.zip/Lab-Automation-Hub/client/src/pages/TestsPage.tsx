import { Layout } from "@/components/Layout";
import { useTests } from "@/hooks/use-tests";
import { FlaskConical, Search, Clock, BadgeDollarSign } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function TestsPage() {
  const { data: tests, isLoading } = useTests();
  const [search, setSearch] = useState("");

  const filteredTests = tests?.filter(t => 
    t.name.toLowerCase().includes(search.toLowerCase()) || 
    t.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 font-display">Lab Tests Catalog</h1>
        <p className="text-slate-500 mt-1">Available diagnostic tests and pricing.</p>
      </div>

      <div className="mb-6 relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
        <Input 
          placeholder="Search by test name or code..." 
          className="pl-9 bg-white border-slate-200"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredTests?.map(test => (
          <div key={test.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all group">
            <div className="flex items-start justify-between mb-4">
              <div className="p-2.5 bg-blue-50 text-primary rounded-xl group-hover:bg-primary group-hover:text-white transition-colors">
                <FlaskConical className="h-6 w-6" />
              </div>
              <span className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-xs font-mono font-medium">
                {test.code}
              </span>
            </div>
            
            <h3 className="font-bold text-slate-900 mb-1 line-clamp-1">{test.name}</h3>
            <p className="text-xs text-slate-500 mb-4 line-clamp-2 h-8">
              {test.description || "No description available for this test."}
            </p>

            <div className="flex items-center justify-between pt-4 border-t border-slate-50">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Clock className="h-3.5 w-3.5" />
                {test.turnaroundTime} hours
              </div>
              <div className="font-bold text-slate-900 flex items-center gap-1">
                <BadgeDollarSign className="h-4 w-4 text-emerald-600" />
                ${(test.price / 100).toFixed(2)}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Layout>
  );
}
