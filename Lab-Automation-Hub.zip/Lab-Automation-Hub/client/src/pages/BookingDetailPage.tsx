import { useRoute } from "wouter";
import { Layout } from "@/components/Layout";
import { useBooking, useUpdateBookingStatus, useUploadResult } from "@/hooks/use-bookings";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  ArrowLeft, 
  User, 
  Phone, 
  MapPin, 
  Calendar, 
  Clock, 
  FileText, 
  Upload,
  Download,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import { bookingStatuses } from "@shared/routes";
import { useRef } from "react";

export default function BookingDetailPage() {
  const [, params] = useRoute("/bookings/:id");
  const id = parseInt(params?.id || "0");
  const { data, isLoading } = useBooking(id);
  const updateStatus = useUpdateBookingStatus();
  const uploadResult = useUploadResult();
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-6">
          <Skeleton className="h-8 w-1/3" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Skeleton className="h-64 md:col-span-2" />
            <Skeleton className="h-64" />
          </div>
        </div>
      </Layout>
    );
  }

  if (!data) return <Layout><div>Booking not found</div></Layout>;

  const { booking, patient, tests, result } = data;

  const handleStatusChange = (newStatus: typeof bookingStatuses[number]) => {
    updateStatus.mutate({ id, status: newStatus });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      uploadResult.mutate({ id, file: e.target.files[0] });
    }
  };

  return (
    <Layout>
      <div className="mb-8">
        <Button variant="ghost" className="mb-4 pl-0 hover:bg-transparent hover:text-primary" onClick={() => window.history.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Bookings
        </Button>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold font-display text-slate-900">
                Booking #{booking.bookingRef}
              </h1>
              <StatusBadge status={booking.status} />
            </div>
            <p className="text-slate-500 flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Created on {format(new Date(booking.createdAt!), "MMMM do, yyyy 'at' h:mm a")}
            </p>
          </div>

          <div className="flex gap-2">
            {booking.status === "BOOKED" && (
              <Button onClick={() => handleStatusChange("ARRIVED")}>Mark Arrived</Button>
            )}
            {booking.status === "ARRIVED" && (
              <Button onClick={() => handleStatusChange("SAMPLE_COLLECTED")}>Collect Sample</Button>
            )}
            {booking.status === "SAMPLE_COLLECTED" && (
              <Button onClick={() => handleStatusChange("IN_PROCESS")}>Start Processing</Button>
            )}
            {booking.status === "IN_PROCESS" && (
              <Button onClick={() => fileInputRef.current?.click()} className="btn-primary">
                <Upload className="h-4 w-4 mr-2" /> Upload Result
              </Button>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept=".pdf" 
              onChange={handleFileUpload}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="md:col-span-2 space-y-6">
          {/* Patient Card */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <User className="h-5 w-5 text-primary" /> Patient Information
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase">Full Name</label>
                <p className="font-medium text-slate-900">{patient.name}</p>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase">Phone</label>
                <div className="flex items-center gap-2">
                  <Phone className="h-3 w-3 text-slate-400" />
                  <p className="font-medium text-slate-900">{patient.phone}</p>
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase">Age / Gender</label>
                <p className="font-medium text-slate-900">{patient.age} years / {patient.gender}</p>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase">Address</label>
                <div className="flex items-center gap-2">
                  <MapPin className="h-3 w-3 text-slate-400" />
                  <p className="font-medium text-slate-900 truncate">{patient.address || "N/A"}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Tests List */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" /> Requested Tests
            </h3>
            <div className="space-y-3">
              {tests.map(test => (
                <div key={test.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <div>
                    <p className="font-semibold text-slate-900">{test.name}</p>
                    <p className="text-xs text-slate-500 uppercase tracking-wider">{test.code}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-slate-900">${(test.price / 100).toFixed(2)}</p>
                    <div className="flex items-center gap-1 text-xs text-slate-500 justify-end">
                      <Clock className="h-3 w-3" />
                      {test.turnaroundTime}h
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 pt-4 border-t border-slate-100 flex justify-between items-center">
              <span className="font-medium text-slate-500">Total Amount</span>
              <span className="text-2xl font-bold text-primary">${(booking.totalAmount / 100).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          {/* Status Timeline */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="font-bold text-lg mb-4">Timeline</h3>
            <div className="space-y-6 relative pl-2">
              <div className="absolute left-2 top-2 bottom-2 w-0.5 bg-slate-100" />
              {/* This is a simplified timeline visualization based on current status */}
              <div className="relative pl-6">
                <div className="absolute left-[-5px] top-1 h-3 w-3 rounded-full bg-primary ring-4 ring-white" />
                <p className="text-sm font-semibold text-slate-900">Booked</p>
                <p className="text-xs text-slate-500">{format(new Date(booking.createdAt!), "MMM d, h:mm a")}</p>
              </div>
              
              {["ARRIVED", "SAMPLE_COLLECTED", "IN_PROCESS", "COMPLETED", "DELIVERED"].map((s, idx) => {
                const isCompleted = bookingStatuses.indexOf(booking.status as any) >= bookingStatuses.indexOf(s as any);
                const isCurrent = booking.status === s;
                
                return (
                  <div key={s} className="relative pl-6">
                     <div className={`absolute left-[-5px] top-1 h-3 w-3 rounded-full ring-4 ring-white transition-colors ${
                       isCompleted ? "bg-primary" : "bg-slate-200"
                     }`} />
                    <p className={`text-sm font-semibold ${isCompleted ? "text-slate-900" : "text-slate-400"}`}>
                      {s.replace("_", " ")}
                    </p>
                    {isCurrent && <p className="text-xs text-primary font-medium mt-0.5">Current Status</p>}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Results Area */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="font-bold text-lg mb-4">Lab Results</h3>
            {result ? (
              <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 text-center">
                <div className="h-10 w-10 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
                  <CheckCircle2 className="h-6 w-6" />
                </div>
                <h4 className="font-semibold text-emerald-900 mb-1">Results Ready</h4>
                <p className="text-xs text-emerald-700 mb-4">Uploaded on {format(new Date(result.createdAt!), "MMM d, yyyy")}</p>
                <Button variant="outline" className="w-full border-emerald-200 text-emerald-700 hover:bg-emerald-100 hover:text-emerald-800">
                  <Download className="h-4 w-4 mr-2" /> Download PDF
                </Button>
              </div>
            ) : (
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-center">
                <div className="h-10 w-10 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-2">
                  <AlertCircle className="h-6 w-6" />
                </div>
                <h4 className="font-medium text-slate-700 mb-1">Pending Results</h4>
                <p className="text-xs text-slate-500">Results have not been uploaded yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
