import { useState } from "react";
import { Layout } from "@/components/Layout";
import { useBookings, useCreateBooking } from "@/hooks/use-bookings";
import { usePatients } from "@/hooks/use-patients";
import { useTests } from "@/hooks/use-tests";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Plus, Filter, Calendar as CalendarIcon, Loader2, Check } from "lucide-react";
import { format } from "date-fns";
import { Link } from "wouter";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { bookingStatuses } from "@shared/routes";

export default function BookingsPage() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const { data: bookings, isLoading } = useBookings(
    statusFilter === "ALL" ? undefined : statusFilter as any, 
    search
  );

  return (
    <Layout>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 font-display">Bookings</h1>
          <p className="text-slate-500 mt-1">Manage patient appointments and test status.</p>
        </div>
        <NewBookingDialog />
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input 
              placeholder="Search by patient name or ID..." 
              className="pl-9 bg-slate-50 border-slate-200"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-[180px]">
              <Filter className="h-4 w-4 mr-2 text-slate-500" />
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All Statuses</SelectItem>
              {bookingStatuses.map(s => (
                <SelectItem key={s} value={s}>{s.replace('_', ' ')}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="p-12 text-center text-slate-500 flex flex-col items-center">
            <Loader2 className="h-8 w-8 animate-spin mb-4 text-primary" />
            <p>Loading bookings...</p>
          </div>
        ) : bookings?.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CalendarIcon className="h-8 w-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900">No bookings found</h3>
            <p className="mb-6">Try adjusting your filters or create a new booking.</p>
            <NewBookingDialog />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Ref ID</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Patient</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Tests</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {bookings?.map(({ booking, patient, testCount }) => (
                  <tr key={booking.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="font-mono text-xs font-medium text-slate-500">
                        {booking.bookingRef}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <div className="font-medium text-slate-900">{patient.name}</div>
                        <div className="text-xs text-slate-500">{patient.phone}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                      {format(new Date(booking.createdAt!), "MMM d, yyyy")}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                      {testCount} tests
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <StatusBadge status={booking.status} />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <Link href={`/bookings/${booking.id}`} className="text-primary hover:text-primary/80 font-medium text-sm">
                        View Details
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Layout>
  );
}

function NewBookingDialog() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [selectedPatientId, setSelectedPatientId] = useState<string>("");
  const [selectedTests, setSelectedTests] = useState<number[]>([]);
  
  const { data: patients } = usePatients();
  const { data: tests } = useTests();
  const createBooking = useCreateBooking();
  const { toast } = useToast();

  const handleCreate = () => {
    if (!selectedPatientId || selectedTests.length === 0) return;
    
    createBooking.mutate({
      patientId: parseInt(selectedPatientId),
      testIds: selectedTests,
    }, {
      onSuccess: () => {
        setOpen(false);
        setStep(1);
        setSelectedPatientId("");
        setSelectedTests([]);
      }
    });
  };

  const toggleTest = (id: number) => {
    setSelectedTests(prev => 
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="btn-primary">
          <Plus className="h-4 w-4 mr-2" />
          New Booking
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden gap-0">
        <div className="p-6 bg-slate-50 border-b border-slate-200">
          <DialogTitle className="text-xl font-display">Create New Booking</DialogTitle>
          <div className="flex items-center gap-2 mt-4">
            <div className={`h-2 flex-1 rounded-full ${step >= 1 ? 'bg-primary' : 'bg-slate-200'}`} />
            <div className={`h-2 flex-1 rounded-full ${step >= 2 ? 'bg-primary' : 'bg-slate-200'}`} />
            <div className={`h-2 flex-1 rounded-full ${step >= 3 ? 'bg-primary' : 'bg-slate-200'}`} />
          </div>
        </div>

        <div className="p-6">
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Select Patient</h3>
              <p className="text-sm text-slate-500 mb-4">Choose an existing patient or create a new one.</p>
              
              <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                {patients?.map(patient => (
                  <div 
                    key={patient.id}
                    onClick={() => setSelectedPatientId(patient.id.toString())}
                    className={`p-4 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                      selectedPatientId === patient.id.toString() 
                        ? "border-primary bg-primary/5 shadow-sm" 
                        : "border-slate-200 hover:border-primary/50"
                    }`}
                  >
                    <div>
                      <p className="font-medium text-slate-900">{patient.name}</p>
                      <p className="text-sm text-slate-500">{patient.phone}</p>
                    </div>
                    {selectedPatientId === patient.id.toString() && (
                      <div className="h-6 w-6 bg-primary rounded-full flex items-center justify-center">
                        <Check className="h-4 w-4 text-white" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <Button onClick={() => setStep(2)} disabled={!selectedPatientId} className="w-full mt-4">
                Next Step
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Select Tests</h3>
              <p className="text-sm text-slate-500 mb-4">Choose laboratory tests to perform.</p>
              
              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                {tests?.map(test => (
                  <div key={test.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
                    <Checkbox 
                      id={`test-${test.id}`} 
                      checked={selectedTests.includes(test.id)}
                      onCheckedChange={() => toggleTest(test.id)}
                    />
                    <div className="grid gap-1.5 leading-none">
                      <label
                        htmlFor={`test-${test.id}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        {test.name}
                      </label>
                      <p className="text-sm text-muted-foreground">
                        ${(test.price / 100).toFixed(2)} • {test.turnaroundTime}h turnaround
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => setStep(1)} className="flex-1">Back</Button>
                <Button onClick={() => setStep(3)} disabled={selectedTests.length === 0} className="flex-1">Next Step</Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="text-center py-6">
                <div className="h-16 w-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CalendarIcon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold font-display text-slate-900">Confirm Booking</h3>
                <p className="text-slate-500 mt-2">
                  Patient: <span className="font-medium text-slate-900">{patients?.find(p => p.id.toString() === selectedPatientId)?.name}</span>
                </p>
                <p className="text-slate-500">
                  Tests: <span className="font-medium text-slate-900">{selectedTests.length} selected</span>
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Subtotal</span>
                  <span className="font-medium">
                    ${(tests?.filter(t => selectedTests.includes(t.id)).reduce((acc, t) => acc + t.price, 0)! / 100).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Service Fee</span>
                  <span className="font-medium">$5.00</span>
                </div>
                <div className="border-t border-slate-200 pt-2 flex justify-between font-bold text-slate-900">
                  <span>Total</span>
                  <span>
                    ${((tests?.filter(t => selectedTests.includes(t.id)).reduce((acc, t) => acc + t.price, 0)! + 500) / 100).toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setStep(2)} className="flex-1">Back</Button>
                <Button onClick={handleCreate} disabled={createBooking.isPending} className="flex-1 btn-primary">
                  {createBooking.isPending ? <Loader2 className="animate-spin mr-2 h-4 w-4" /> : null}
                  Confirm & Create
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
