import { Layout } from "@/components/Layout";
import { useAnalyticsOverview } from "@/hooks/use-analytics";
import { StatCard } from "@/components/StatCard";
import { 
  Users, 
  FlaskConical, 
  CheckCircle2, 
  Clock, 
  MessageCircle, 
  TrendingUp,
  Activity
} from "lucide-react";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

// Mock data for charts since the backend returns aggregates only for now
const activityData = [
  { name: 'Mon', bookings: 24, completed: 18 },
  { name: 'Tue', bookings: 32, completed: 28 },
  { name: 'Wed', bookings: 45, completed: 35 },
  { name: 'Thu', bookings: 38, completed: 30 },
  { name: 'Fri', bookings: 52, completed: 48 },
  { name: 'Sat', bookings: 28, completed: 25 },
  { name: 'Sun', bookings: 15, completed: 15 },
];

const LoadingState = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    {[1, 2, 3, 4].map((i) => (
      <Skeleton key={i} className="h-32 rounded-2xl" />
    ))}
  </div>
);

export default function DashboardPage() {
  const { data, isLoading } = useAnalyticsOverview();

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 font-display">Dashboard Overview</h1>
          <p className="text-slate-500 mt-1">Real-time laboratory insights and performance metrics.</p>
        </div>

        {isLoading ? <LoadingState /> : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            <StatCard 
              label="Total Bookings" 
              value={data?.totalBookings || 0}
              icon={Users}
              color="blue"
              trend={{ value: 12, isPositive: true }}
            />
            <StatCard 
              label="Avg Turnaround" 
              value={`${data?.avgTurnaroundTime || 0}h`}
              icon={Clock}
              color="purple"
              trend={{ value: 5, isPositive: true }}
            />
            <StatCard 
              label="WhatsApp Delivery" 
              value={`${data?.whatsappDeliveryRate || 0}%`}
              icon={MessageCircle}
              color="green"
            />
            <StatCard 
              label="Revenue Estimate" 
              value={`$${((data?.revenue || 0) / 100).toFixed(2)}`}
              icon={TrendingUp}
              color="orange"
            />
          </motion.div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Chart */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-bold font-display text-slate-900">Weekly Activity</h3>
                <p className="text-sm text-slate-500">Bookings vs Completed Tests</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <div className="w-2 h-2 rounded-full bg-primary" /> Bookings
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <div className="w-2 h-2 rounded-full bg-emerald-400" /> Completed
                </div>
              </div>
            </div>
            
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={activityData}>
                  <defs>
                    <linearGradient id="colorBookings" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                    cursor={{ stroke: '#cbd5e1', strokeWidth: 1 }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="bookings" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorBookings)" 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="completed" 
                    stroke="#34d399" 
                    strokeWidth={2}
                    fill="none"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Side Widget */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-primary p-6 rounded-2xl shadow-lg shadow-primary/20 text-white relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Activity className="h-32 w-32" />
            </div>
            
            <h3 className="text-xl font-bold font-display mb-2 relative z-10">Lab Performance</h3>
            <p className="text-blue-100 text-sm mb-8 relative z-10">Your laboratory is performing better than last week.</p>

            <div className="space-y-4 relative z-10">
              <div>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-blue-100">Sample Processing</span>
                  <span className="font-bold">92%</span>
                </div>
                <div className="h-2 bg-blue-900/30 rounded-full overflow-hidden">
                  <div className="h-full bg-white rounded-full w-[92%]" />
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-blue-100">Equipment Usage</span>
                  <span className="font-bold">78%</span>
                </div>
                <div className="h-2 bg-blue-900/30 rounded-full overflow-hidden">
                  <div className="h-full bg-white rounded-full w-[78%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-blue-100">Report Generation</span>
                  <span className="font-bold">98%</span>
                </div>
                <div className="h-2 bg-blue-900/30 rounded-full overflow-hidden">
                  <div className="h-full bg-white rounded-full w-[98%]" />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
