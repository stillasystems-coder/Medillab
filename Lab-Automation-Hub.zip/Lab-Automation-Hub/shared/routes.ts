import { z } from 'zod';
import { 
  insertUserSchema, 
  insertPatientSchema, 
  insertTestSchema, 
  insertBookingSchema, 
  users, 
  patients, 
  tests, 
  bookings, 
  results,
  userRoles,
  bookingStatuses
} from './schema';

// Common error schemas
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// API Definitions
export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/auth/login' as const,
      input: z.object({
        username: z.string(),
        password: z.string(),
      }),
      responses: {
        200: z.object({
          token: z.string(),
          user: z.custom<typeof users.$inferSelect>(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
    register: {
      method: 'POST' as const,
      path: '/api/auth/register' as const,
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  patients: {
    list: {
      method: 'GET' as const,
      path: '/api/patients' as const,
      input: z.object({
        search: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof patients.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/patients' as const,
      input: insertPatientSchema,
      responses: {
        201: z.custom<typeof patients.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  tests: {
    list: {
      method: 'GET' as const,
      path: '/api/tests' as const,
      responses: {
        200: z.array(z.custom<typeof tests.$inferSelect>()),
      },
    },
  },
  bookings: {
    create: {
      method: 'POST' as const,
      path: '/api/bookings' as const,
      input: z.object({
        patientId: z.number().optional(),
        patient: insertPatientSchema.optional(),
        testIds: z.array(z.number()),
        branchId: z.string().optional(),
      }),
      responses: {
        201: z.object({
          booking: z.custom<typeof bookings.$inferSelect>(),
          tests: z.array(z.custom<typeof tests.$inferSelect>()),
          patient: z.custom<typeof patients.$inferSelect>(),
        }),
        400: errorSchemas.validation,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/bookings' as const,
      input: z.object({
        status: z.enum(bookingStatuses).optional(),
        search: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.object({
          booking: z.custom<typeof bookings.$inferSelect>(),
          patient: z.custom<typeof patients.$inferSelect>(),
          testCount: z.number(),
        })),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/bookings/:id' as const,
      responses: {
        200: z.object({
          booking: z.custom<typeof bookings.$inferSelect>(),
          patient: z.custom<typeof patients.$inferSelect>(),
          tests: z.array(z.custom<typeof tests.$inferSelect>()),
          result: z.custom<typeof results.$inferSelect>().optional(),
        }),
        404: errorSchemas.notFound,
      },
    },
    updateStatus: {
      method: 'PATCH' as const,
      path: '/api/bookings/:id/status' as const,
      input: z.object({
        status: z.enum(bookingStatuses),
      }),
      responses: {
        200: z.custom<typeof bookings.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    uploadResult: {
      method: 'POST' as const,
      path: '/api/bookings/:id/result' as const,
      // Input is FormData, handled separately
      responses: {
        201: z.custom<typeof results.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  analytics: {
    overview: {
      method: 'GET' as const,
      path: '/api/analytics/overview' as const,
      responses: {
        200: z.object({
          totalBookings: z.number(),
          avgTurnaroundTime: z.number(),
          whatsappDeliveryRate: z.number(),
          revenue: z.number(),
        }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      url = url.replace(`:${key}`, String(value));
    });
  }
  return url;
}

export { bookingStatuses, userRoles };
